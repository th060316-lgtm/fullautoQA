# License / Attribution inventory

This privately returned checkpoint preserves the supplied payloads byte for byte. It is not cleared for public redistribution. See original notices under LICENSES and inside each payload. No legal clearance or corresponding-source compliance is asserted.

| Software | Supplied version | License evidence / note |
|---|---|---|
|java|21.0.12.1+1|GPL-2.0 with Classpath Exception|
|git|2.56.0.2|GPL-2.0 and bundled components|
|godot|4.7.2|MIT and third-party licenses|
|node|22.21.0|MIT and bundled third-party licenses|
|c|2.10.1|Mixed; component licenses require review|
|python|3.13.15.0dot|PSF, MIT, and bundled package licenses|
|ffmpeg|9.0.2|GPL-3.0 per supplied LICENSE|
|ahk|2.0.31|GPL-2.0|
|obs|33.0.1|GPL-2.0 and bundled third-party licenses|
|oculix|4.0.0|Mixed; inspect included OculiX/SikuliX component texts|

CORE and fixtures are newly generated for this request. No third-party QA ZIP code was copied. CORE imports standard-library modules only. Bundled Python packages and versions are listed in python_packages.json.

The original Godot ZIP has no standalone license file in its two-entry payload. Godot third-party notices, Git installer and w64devkit component source/license obligations require further release review. Do not treat a short top-level license label as exhaustive licensing of a toolchain.