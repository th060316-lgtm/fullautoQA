FullAutoQA 0.3.3 候補 — Target Game Binding

大目標: 対象ゲームを明示したうえで、展開 → START_QA.cmd 1回 → RESULTS/<Run ID>/RESULT_FOR_CHATGPT.zip まで自動実行する。

重要:
- START_QA.cmd は QA_TARGETS.json に明示された対象ゲームだけを「Target QA」として実行する。
- QA_TARGETS.json が無い場合、実ゲームQAは NO_TARGET_CONFIGURED で合格しない。Fixtureが代わりに本番対象として走ることはない。
- 同梱Fixtureの装置自己診断は START_SELFTEST.cmd で実行する。自己診断がPASSしても target_qa_certified / completion_certified は true にならない。
- QA_TARGETS.example.json は雛形。ゲーム追加時にProfile/必要なAdapterと合わせて QA_TARGETS.json を作る。
- Logicのみ: START_LOGIC.cmd。Playableのみ: START_PLAYABLE.cmd。
- 1時間: START_LONG_SOAK.cmd。24時間: START_SOAK_24H.cmd。時間は選択されたTarget Profileへ適用される。

結果:
終了時に表示される RESULTS/<実際のRun ID>/RESULT_FOR_CHATGPT.zip を返却する。
RESULTS/latest.json は案内用で、latestという実行フォルダではない。
Target runでは player_review_packet.json もZIPへ入り、動画・画像・目的・操作・シナリオ・coverageを後段のPlayer/Product reviewへ渡す。これは自動証拠であり、人間の満足度を証明したとは扱わない。

Regression:
同一Run内で作るbaselineは決定性・再現性の自己確認であり、過去版Regressionとは別物。
QA_TARGETS.jsonで historical_regression を要求する場合は、過去Runのbaseline_exportsを含むRESULT_FOR_CHATGPT.zip等を baseline に指定する。未指定ならTarget certificationを通さない。

Source/Reviewは査読用で同梱ランタイムを含まない。単独実行用ではない。
完全Candidateは同梱Payload/Runtimeを含む。
ゲーム/Engine/Tool/OS固有条件は、必要な場合にProfile/Target契約へ明示し、COREの普遍条件へ勝手に昇格させない。

詳細: DEVELOPER/GAME_INTEGRATION.md
既存ライセンス資料は LICENSES 等に保持。公開再配布可否は別途ライセンス審査対象。
