# FullAutoQA 0.3.2 修正候補の監査

製品受入は **HOLD**。5つのAI独立査読視点による承認は修正・出力の実装範囲に対するもので、実在の人間による会議、Windows実機合格、実ゲーム適合認定を意味しない。旧0.3.1成果物は保持し、0.3.2を別候補として扱う。

## 入力と確認事実

現行のSource、Review、Join、Acceptance、SHA256SUMS、E2Eを取得して現物確認の入力とした。ユーザー提出の旧0.3.1 `RESULTS.zip`も診断入力である。

- Windows実行では同梱Godot fixtureの`fixture.gd:26`にspeed型推論Parse Error。5 Profileすべてbuild FAILとなり、主要操作試験はNOT_RUNだった。
- 約39.8秒の動画が記録されていた。取得動画は全ゲーム試験の成立を証明しない。
- 通常実行とbootstrap失敗の両方に`RESULT_FOR_CHATGPT.zip`が存在し、CRC確認に合格した。今回の指摘を「ZIP機能が未実装だった」と扱わない。
- bootstrap_errorには、日本語Windowsパスを含むlatest.jsonの文字化けとJSON解析失敗が残っていた。結果生成と結果案内の失敗は区別する。

旧Windows証拠の根拠entry: `RESULTS/20261101T214027_9447adfa/fixture_grid.build.log`、`result.json`、`RESULT_FOR_CHATGPT.zip`、`RESULTS/bootstrap_20261101T124205_8e8561ed/bootstrap_error.txt`、同`RESULT_FOR_CHATGPT.zip`。

## 今回の是正範囲

1. Godotの該当計算へ明示型を付け、PowerShellのJSON読込みをUTF-8／LiteralPathへ統一する。
2. QA判定と表示処理を分離。cleanup、report、manifest、ZIPの最終化を個別保護し、lock解放も独立させる。
3. 実行前にProfileから必須case一覧を固定し、欠落・重複・NOT_RUNを照合。無効なgoal/test参照を拒否する。
4. manifestとZIPの収録方針を共通化し、除外物を別一覧化。参照整合とCRCを確認したZIPのみ発行し、保存不能は明示する。
5. Logic／Playable別の判定と、今回のZIP所在・ファイル用途を明示する。

これらは修正対象の説明であり、記載だけで検証完了とはしない。最終テスト結果と成果物hashは、同梱の当該版の受入記録・検証ログを参照する。旧版ログの合格数を0.3.2の検証数として転記しない。

## 検証の境界

| 対象 | 現時点の扱い |
| --- | --- |
| 旧0.3.1 Windows提出結果 | 実行済み。上記build失敗と案内失敗を確認 |
| Fixture/RFB | 制御された参考ゲーム・仮想表示での証拠。Windows固有APIの実証とは区別 |
| 0.3.2 Windows/Godot/PowerShell実機受入 | NOT_RUN。この開発環境には実行環境がない |
| Windows 1h/24h実時間完走 | 未確認。機能や時間方針のテストを完走証拠に代用しない |
| 実ユーザーゲームへの適合 | 未証明。対象ゲーム未提供 |
| 人間の楽しさ・理解しやすさ | 自動試験PASSだけでは認定しない |

## 成果物の用途

| 種類 | 用途と依存 |
| --- | --- |
| Candidate | 同梱ランタイムを含む実行用完全候補。新規展開はこちら |
| 分割Candidate／Join Set | 同一の完全候補を復元するための転送・結合用。結合後のhashを照合 |
| Source | ソース査読・修正用。同梱ランタイムなし。単独実行不可 |
| Review Set | Source、証拠、受入資料などの査読用。同梱ランタイムなし |
| Hotfix | 指定された既存0.3.1専用の差分。元版・hash確認と退避が必要 |
| Acceptance／SHA256SUMS | 判定範囲・未実施と成果物同一性の確認資料 |
| 最新RESULT_FOR_CHATGPT.zip | 実行後に返す診断証拠。今回の実行フォルダから選択 |
| ユーザーのRESULTS.zip | 複数実行を含む有効な診断入力。各実行を区別して読む |

修正候補の配布と製品受入は分離する。新規展開からSTART一回で実行し、正常・ゲームFAIL・装置エラー・日本語パスで証拠の保存と案内を確認する。実ゲームは専用Profile／Adapterを介した実測後に、対応できた範囲を個別認定する。

## 連続時間Fixtureの追加是正

変更前Profileの逆順試験で、goal直後に短縮された5入力を再生すると連続時間差で終点に届かずFAILとなった。旧FAILは保持する。Realtimeの2Profileのみ3.2へ更新し、宣言済み操作列を最後まで実施し、飽和終点も厳密に比較する。中間軌跡の同一性は対象外と明示し、最終状態・操作列・画像・性能比較は維持する。Logic等の軌跡比較は変更しない。これは任意の実ゲームへ自動適用する標準ではない。
