# 対象ゲームの追加と一回START運用 — v0.3.3

FullAutoQAは、ゲーム本体 + 対象用Profile + 必要なAdapter + `QA_TARGETS.json` を組み合わせて自動QAする。COREは任意ゲームのルールを推測して本番仕様に固定しない。

## 1. Target契約

`QA_TARGETS.example.json` を雛形として `QA_TARGETS.json` を作る。Target契約は「どのProfileを本番対象として実行するか」「そのゲーム/段階で何を必須QAとするか」を機械可読にする。

例:

```json
{
  "schema_version": 1,
  "baseline": null,
  "targets": [
    {
      "id": "my_game",
      "profile": "PROFILES/my_game.json",
      "requirements": ["goal", "save_load", "soak", "regression", "faults"]
    }
  ]
}
```

認識するrequirements:
- `goal`: 明示GoalとGoal scenario
- `save_load`: Save契約とSave/Load scenario
- `soak`: qa_plan.soak
- `regression`: qa_plan.regression（同一Run自己比較でも可）
- `historical_regression`: 過去Runからimportしたbaselineとの比較を必須化
- `faults`: qa_plan.faults
- `technical_tests`: tests / technical_tests
- `seed_replay`: verify_seed_replay scenario
- `player_review_evidence`: Playableで、目的/操作/Goalを後段レビューへ渡せること
- `build`: build契約

全部を全ゲームへ強制しない。対象ゲームの機能、Prototype階級、今回の受入目的から必要なものだけ選ぶ。未記載機能をQA済みと見なさない。

`required_agents` は必要時だけ明示できる。省略時はProfileに宣言されたscenarioのAgent集合を必要coverageとして使う。Smoke/Goal/Explorer/Randomの4種を全ゲームへ機械的に強制しない。

## 2. ゲーム/Profile/Adapter

1. 対象ゲームをGAME側へ配置する。試験は実行ごとのコピーを使い、元ゲーム/既存Saveを保護する。
2. Profileへsource、build/launch、prototype_type、actions、goals、tests、scenarios、observations、save、時間予算等を対象ゲームに合わせて宣言する。
3. 既定観測では不足する場合だけGAME側Adapterを追加する。Engine固有方式をCOREの普遍仕様へ固定しない。
4. 目標到達と失敗を区別できる観測根拠を用意する。設定値そのものを成功証拠に代用しない。
5. Target契約のrequirementsとProfile coverageが一致しない場合、Target runは合格しない。

同梱 `fixture_*` Profileは `qa_role=selftest` とし、Target契約から本番対象として使えない。Fixtureは `START_SELFTEST.cmd` で装置自己診断に使う。

## 3. Regressionの区別

qa_plan.regressionがあり過去baselineを指定しない場合、FullAutoQAは同一Runでbaselineを作り、同じSeed/Actionを再実行して決定性・視覚・性能の自己比較を行える。これは **SAME_RUN_SELF_CHECK** であり、過去版Regressionではない。

`historical_regression` をTarget要件にする場合、`QA_TARGETS.json` の `baseline` に過去Runの `RESULT_FOR_CHATGPT.zip`（baseline_exportsを含む）またはbaseline_exports directoryを指定する。importされて実比較がPASSしない限りTarget certificationは通らない。

## 4. 日常運用

- 本番対象QA: `START_QA.cmd`
- Fixture自己診断: `START_SELFTEST.cmd`
- Logicのみ: `START_LOGIC.cmd`
- Playableのみ: `START_PLAYABLE.cmd`
- Soak: `START_LONG_SOAK.cmd` / `START_SOAK_24H.cmd`

`START_QA.cmd` に `-Profile` を明示した実行はadhoc検証として動かせるが、Target契約を通らないため `completion_certified=true` にはしない。これによりFixture/一時ProfileのPASSを本番ゲームQA完了へ昇格させない。

## 5. Player/Product reviewへの受渡し

Target runは `player_review_packet.json` を生成し、対象Profile、instructions、controls、goals、scenarios、coverage、動画/画像証拠への参照をまとめる。これを `RESULT_FOR_CHATGPT.zip` とともにChatGPT/制作取締役会へ返すことで、人間が手動でログを拾い集める工程を減らす。

ただし自動証拠は「実在ユーザーが面白いと感じた」「初見ユーザー全員が理解した」の証明ではない。Playable以上のPlayer/Product Acceptanceでは、自動証拠によるモデル査読と、必要なら実人間試遊を区別する。
