# 0.2.0 rework architecture

This version modifies the existing implementation in place; the original 0.1.0 bundle remains unchanged in its existing return location. It preserves every original tool payload and game/profile. The newly added Git runtime supplements, rather than deletes, the supplied Inno Setup installer.

## Host boundaries and real GUI validation

`CORE/runner.py` dispatches by requested/detected backend and profile. `CORE/windows_runner.py` preserves the native Windows desktop suite, with process/display creation routed through backend interfaces. `CORE/backends.py` provides process supervision, display/input/capture, process metrics, recording and detected tool execution. Native Windows uses Job Objects, SendInput/BitBlt and FFmpeg gdigrab. Functional host validation uses real processes exporting real software-rendered GUI framebuffers over standard RFB 3.8. Those fixtures are actual playable graphical programs and can also be operated by an RFB/VNC viewer. They do not create an X11/Wayland window or a Windows desktop window.

The RFB client negotiates the server's dimensions, sends protocol KeyEvent/PointerEvent messages, and receives actual raw FramebufferUpdate pixels. No agent action writes game state. Observations read an independent, game-authored JSON bridge. Rendering and rule updates happen in the launched fixture process. The harness records actual displayed frames on a monotonic VFR timeline; it never generates screenshots from expected states. FFmpeg encodes the observed frames and ffprobe checks the produced video stream, duration, and frame timeline. Sampling and maximum interframe gap are disclosed in video.timeline.json; this is not a high-frame-rate desktop recording claim.

Independent fixture programs under GAME/virtual use materially different interactions: Grid Rescue (arrow keys and turns), Workshop Market (mouse-selected production/turn/sale UI), Crossroads Story (keyboard dialogue and mouse branching), Realtime Runner (held D/A input with movement over elapsed time and failure/retry), and Seeded Expedition (random events and seed/action replay). They share a display/protocol utility but have separate gameplay source and different action maps. These examples demonstrate two adapter paths (bridge/keyboard and screen-color target/pointer) and a non-Godot standalone path. They do not prove autonomous mastery of every genre or engine.

`image_recognition` is false in the default adapter. The RFB UI adapter declares only `color_target_localization`, using screenshot RGB region localization against explicitly supplied profile target colors. Mouse coordinates are computed from received pixel dimensions and recorded alongside normalized/pixel transforms. General OCR/object understanding is unsupported. Exclusive virtual-display focus is recorded as such; it is not misreported as successful OS foreground focus. The native Windows wrapper verifies foreground success when selected, but DPI/fullscreen/monitor qualification for the legacy Windows desktop path remains pending.

## Gates and certification

Every verdict records REQUIRED, OPTIONAL, UNSUPPORTED_FOR_PROFILE or INFORMATIONAL. Only REQUIRED gates determine overall PASS. Missing or NOT_RUN required gates block PASS; unavailable optional OCR/gamepad and inapplicable Windows tools remain visible without poisoning a Linux functional run. Injected game faults remain visible as FAIL, with INFORMATIONAL scope, while separate REQUIRED detector gates assert that the expected failure was actually observed. This avoids treating successful fault detection as a broken normal product while retaining the defect evidence.

`certify()` requires an explicit nonempty set of gates, real evidence references, a package version and applicable target. Host reports compute `functional_e2e_certified` from required functional gates; Windows product `completion_certified` also requires Windows desktop and ten-tool qualification. Neither result is a constant. Candidate product certification remains false until its required product evidence exists. Unit tests demonstrate both reachable certification and missing-required-gate rejection.

RESULT_FOR_CHATGPT.zip now includes the actual full video and all referenced screenshots/logs/baselines/probes. Working copies and transient video encoder frame files are excluded. Each ZIP is mechanically audited for missing verdict evidence; there is no manually located second evidence folder for the functional validation run.

## Git runtime

Git Windows x64 binaries and their DLLs were obtained from the official git-for-windows/git CI artifact `vs-artifacts-x64`, artifact 13029368636, run 41166509480, source commit 509985b0eaea6372efacd8c64e8d9d8ab3f558d1. The downloaded ZIP SHA-256 matches GitHub's artifact digest: 3ade59c9a3054eb6476c8789cb773afed45d1e4bfbd143f54e4b682005e36e81. Provenance and per-file hashes are in git_runtime_manifest.json. Original artifacts.tar.gz and tracked.tar.gz are retained inside PAYLOAD/GitForWindows_OfficialCI_x64.zip, including corresponding tracked Git source. The original required Git-2.56.0.2-64-bit.exe is retained unchanged.

The hard-linked git.exe in the CI tar was resolved to its actual 4,154,368-byte executable, not saved as a zero-length tar link. Required non-OS DLLs are adjacent, with bundled WinPython's existing VC runtime DLLs copied alongside. PE import inspection is evidence of dependency structure, not execution. Windows system DLLs and Universal CRT API sets are OS prerequisites. This is an official CI build, not an asserted stable PortableGit release. Scripted hooks/helpers requiring a shell are not qualified by a bare Git version probe.

The native Windows tool preflight verifies the Git runtime manifest, executes `git --version`, then runs an isolated `git init --bare` with explicit local exec/template/config paths. That execution is still NOT_RUN here. Deterministic absence of git.exe is repaired; actual Windows runtime usability still requires qualification. It must not be treated as a Linux Git probe proving the Windows binary.

## Baselines, discovery, soak and limits

A shipped Grid baseline is captured from real framebuffer input and stored under BASELINES/VALIDATION/rfb_grid. Runs compare actual screenshots, expected state and observed startup time against it. A separate same-run good baseline demonstrates the injected visual regression detection. Startup maximum is an explicit five-second acceptance budget, not an invented historical measurement. The default functional soak runs for 30 seconds with real repeated input and process samples. It is not labelled a five-minute test.

Causal control discovery records action-to-changed-state fields from real input. Agent memories, exploration, loop fallback and recorded effects remain bounded heuristics. A game-specific profile is explicitly required. Zero-configuration play, 30-second cognitive readability/enjoyment judgement, OCR, audio and gamepad are not claimed.

Legacy limitations not repaired by this change include generic multiple-slot/autosave/interrupted-save workflows, exact interruption-point resume, automatic arbitrary-defect save replay, broad performance/frame-time regression and unqualified Windows DPI/fullscreen/OBS/OculiX visual workflows. These remain unsupported/unfinished rather than silently promoted to PASS.
