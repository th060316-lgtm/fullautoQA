# FullAutoQA v0.3.3 internal audit — target binding hardening

## Purpose

v0.3.2 proved the harness, RFB functional E2E, fault detection, save/load, soak, regression machinery and packaging path, but the packaged Windows default could select bundled Fixture Profiles when no production target game was configured. That made a fixture-only PASS structurally capable of being mistaken for target-game QA completion.

v0.3.3 changes the certification boundary without deleting the v0.3.2 evidence or fixtures.

## Adopted changes

- `START_QA.cmd` default now requires `QA_TARGETS.json` and runs only Profiles declared there.
- Missing target configuration produces `NO_TARGET_CONFIGURED`; it cannot certify target QA.
- `START_SELFTEST.cmd` runs the five bundled Windows Fixture Profiles as an explicit harness/package self-test.
- Explicit `-Profile` runs remain available as adhoc QA but cannot set target completion certification.
- Bundled Fixture Profiles carry `qa_role=selftest`; Target contracts reject them as production targets.
- `QA_TARGETS.json` can declare per-game requirements rather than forcing Save/Load, Soak, Regression, Faults, seed replay, build, etc. onto every game.
- Required Agent coverage defaults to the Agents actually declared by the Target Profile; all four Agent types are no longer a universal certification assumption.
- `historical_regression` is distinct from same-run deterministic self-check. It requires an imported previous-run baseline and an observed PASS comparison.
- Target runs package `player_review_packet.json` with purpose/control/goal/scenario/coverage and visual-evidence references. It is automated evidence, not a human-satisfaction claim.
- Windows native package qualification is kept but separated from target-game QA certification in `acceptance_manifest.json`.
- Old 0.1 Architecture/Acceptance files are retained as historical checkpoints instead of silently deleting them.

## Verification in this build environment

- Python unit/regression suite: 138 tests PASS (v0.3.2 had 128; v0.3.3 adds 10 target-binding tests).
- Python compileall: PASS.
- `verify_core`: PASS after regenerated core manifest.
- RFB logic GUI/input validation with faults: PASS after v0.3.3 changes.
- Direct Windows-runner negative target test on this non-Windows host: missing `QA_TARGETS.json` creates a result ZIP with HARNESS_ERROR / `NO_TARGET_CONFIGURED`, `target_qa_certified=false`, `completion_certified=false`.
- Native Windows gameplay after this patch: NOT_RUN in this environment. This is backend qualification, not a universal target-game requirement.

## Remaining boundary

No real user game was supplied in this package, so no production game can be target-certified by this audit. A game integration must provide the game, a Profile, any required Adapter, and a `QA_TARGETS.json` contract chosen from the actual game/stage requirements. Playable/Product Acceptance still distinguishes automated evidence from actual human satisfaction.
