# v0.2への現物修正: 0.3.0-candidate

## 受入範囲と制限
Windows x64は製品対象OSとして明示。Linuxは既存RFB機能検証用の実行ホスト。
この版のWindows実機E2E、Windows Fresh Extract、PowerShell更新スクリプトの実行はNOT_RUN。
RFBはゲーム所有の仮想ディスプレイでありOSのネイティブウィンドウではない。実プロセス、RFB鍵盤・ポインタイベント、実画面ピクセル、独立State Bridgeを使用する。
RFBのPASSをWindows完成認定へ昇格させない。30秒/5分の楽しさ、OCR、音声、Gamepad、OculiX Visualは未検証。
Soakはレポート記載の実測秒数のみ。短いSoakを長時間信頼性の実証とは呼ばない。

## 重点修正
CORE/assets.py: GDScriptのglobalize_pathなど任意文字列をAsset扱いしない。
required_assets、実load/preload、Scene resource参照を検査し、generated_paths/save/bridge/endpointを事前入力と分離。
明示required_assetsは生成物除外に優先。原本でなくRun別Working Copyを破壊試験に使う。
CORE/recording.py: 要件は連続動画証拠。実装は利用可能Backendで選択。
Windowsではdesktop_ffmpeg、失敗時captured_framesの順をManifestで指定。
OBSは同梱するが動画の唯一の実装ではない。OBS診断の失敗はOPTIONAL。
required_tools指定にはidと製品要件としてのreasonが必須。利用可能録画手段が全滅したらHARNESS_ERROR。
CORE/plans.py/host_runner.py: 各Profileのqa_planにFault/Soak/Regression。
game_idやrfb_gridの存在、選択順に依存しない。
各Profile単独で4 Agent、Save/Load、Baseline作成と回帰、Fault、Soakが成立。
RFBでもAgent操作と独立した定期Captureで待機時間の画面も採取。
録画の取得時刻・観測間隔はvideo.timeline.json/continuous_capture.jsonに保存。

## 製品要件と手段
23 Capabilityと動画・実入力・画面・判定・ZIPが要求。
Engine、操作名、Goal、座標、起動argv、Save/State/Endpoint、FaultはProfile。
results/profiles/validation_profilesの場所はacceptance_manifest.paths。
録画Backend優先順と明示必須Toolはacceptance_manifest。
COREは具体的なゲームの識別子を条件分岐に使わない。
Godot参照解析は拡張子に適した補助検査で、他Engineの代わりに実行しない。
現在利用可能な実装の範囲を越える能力はNOT_RUN/HARNESS_ERROR。
RFB実装で混在Display種類を一Runに指定した場合は明確な非互換Error。単一Backend内の複数Profileは任意順。

## 実行
Windows: START_QA.cmd (全通常Profile)、START_LOGIC.cmd、START_PLAYABLE.cmd。
PowerShellから複数指定: ./BOOTSTRAP.ps1 -Profile @('PROFILES/fixture_realtime.json','PROFILES/fixture_grid.json')
機能検証: START_VALIDATION.sh --faults --soak-seconds 30
または Windows START_FUNCTIONAL.cmd。--profile は反復指定可能。
ゲーム追加は既存JSONを複製し、source/launch/actions/observations/goals/save/scenarios/qa_planをゲームに合わせる。
Profile schema=1。互換性なしのSchemaは明確なError。COREの書換えは不要。

## 結果
RESULT_FOR_CHATGPT.zipに全動画・画像・ログ・Profile・故障判定・再現情報を含める。
正常系REQUIRED PASSと、故障注入の生FAILを分離。検出器が期待故障を検出した場合のみdetector PASS。
Optionalの非実行/失敗もレポートから削除しない。
既存43 CORE testsは変更せず保持し、不具合回帰テストを追加。
CORE Manifestは正式リリース処理で更新。通常START中に作り直さない。

## 再構成
DEVELOPER/build_versioned_zip.py --root ROOT --output OUTPUT.zip
package_files_v030.jsonの正確なFile Size/SHA-256を検証し、決定的ZIPを生成。
元v0.2の10系統ペイロードとPython/Git runtimeは同一バイトで保持。
ライセンスは既存LICENSES/LICENSE_ATTRIBUTION.mdを継承。新規外部依存の追加なし。
