# 0.3.1: 実装と実行を分離した残件処理

## 実装済み
- Windows native runnerのSession.executeから、共通campaigns.execute_plansを呼び出す。
- 全5通常ProfileにCrash/Stall/Save/Visual/Loop/Missing AssetのFault契約を宣言。
- Faultの元Profileを複製してRun Copyだけへ適用し、終了/例外時に元のProfileへ戻す。
- 生FAILを削除しない。期待故障の検出器だけをPASSにし、無関係なHARNESS_ERRORの混在を許容しない。
- Crash後のCapture不能を装置故障にしない。生存中のCapture故障はHARNESS_ERROR。
- Soakは指定秒数と指定入力ループ数の双方を満たすまでPASSにしない。
- 1h/24hを指定できる。時間/Action予算で先に止まればSOAK_INCOMPLETE (INCONCLUSIVE)。
- AgentのState/Action Memory、観測履歴、RAM/Handleサンプルを制限し、全ログは逐次File出力。
- RAMとHandleの継続増大をPID単位で候補抽出。候補を確定Leakと言い換えない。
- FFmpeg代替録画もPipeによる逐次エンコード。生BMPを時間に比例して蓄積しない。
- Disk Guard、停止条件、入力解除、所有Process Tree終了を維持。
- Baselineを別RunのResult ZIPまたは展開Directoryから取込可能。
- game_id / Scenario / Seed / 観測Fields / SchemaとSHA-256を検証。Game Version差は許可して記録。
- 同じAction列をReplayし、最終State・Actionごとの遷移・画面の許容差/Mask・性能/RAMを比較。
- 比較に必要なMetric/StateがなければPASSにしない。
- 基準の実Fileも結果ZIPへ複製し、元Baselineを移動してもEvidenceを確認できる。
- 自動生成Baselineには承認済みと表示しない。自己比較とユーザー指定の過去Runを区別する。
- Result ZIPをCRC確認後に原子的に公開。STARTは前回の古いResultを再表示しない。

## Profile設定例
qa_plan.soak: {seconds: 3600, loops: 1000, agent: Random, memory_limit: 1024}
loopsはQA入力反復数。seconds=0なら回数のみ指定。両方0や負数/NaNは非互換Error。
各Profileで起動argv、Actionと物理入力、Goal、Bridge/Save/生成物、Fault引数を宣言。
qa_plan.regression: scenario, state_fields, compare_trajectory, visual_tolerance,
visual_masks (正規化Rect), field_tolerances, performance_limits (ratio/absolute_tolerance/maximum)。
変動し続けるTimerやDebug文字列をFieldsへ無差別に入れない。
必要なら不安定UI領域をProfileのMaskへ明記。全画面Maskは拒否。

## Windows操作
通常はSTART_QA.cmd (Fault suite含む)。
START_LONG_SOAK.cmdは選択Profileごとに3600秒を要求。
START_SOAK_24H.cmdは各86400秒を要求。Disk/時間制限で未達ならPASSにしない。
過去結果との比較: START_QA.cmd -Baseline "C:\QA\previous\RESULT_FOR_CHATGPT.zip"
PowerShell複数選択例:
./BOOTSTRAP.ps1 -Profile @('PROFILES/fixture_realtime.json','PROFILES/fixture_grid.json') -SoakSeconds 60
Faultだけ無効化する明示指定: -NoFaults (NOT_RUN理由を記録)。

## 実機なしでの検証方法
WindowsとRFBを別実装のQAロジックへ分離しない。
CORE/session_validation.pyは同じwindows_runner.Session.executeを実際に呼び、
実Game Process・RFB入力・生画面・独立Bridgeで制御Flowを検証する。SessionのmethodをMockしない。
Native Win32 API、Godot Windows実行、UAC/Driver/実機Captureの実証とは区別する。
START_VALIDATION.sh --profile VALIDATION_PROFILES/rfb_grid.json --faults --soak-seconds 60
開発ホストのLinux専用操作はユーザーへ要求しない。Windowsは上のCMDを利用。

## 残る受入
今回対象のFault suite配線・長時間Soak機能・本格Regression機能に未実装の残件はない。
実行結果は外部の受入Report JSONを正本とする。
WindowsのFresh ExtractからSTART一回、Win32入力/画面/録画、同梱全10 Runtime、
Windowsでの1h/24h Soakと別版ゲームRegressionの実測はNOT_RUN。
1h/24hを実時間で実施したと誤報告しない。
OCR/Audio/Gamepad/OculiX Visualは従来通り任意Capability。未対応をPASSにしない。
任意ゲームの人間と同等の攻略・楽しさは保証しない。

## 更新と再構成
配布UpdateのAPPLY_UPDATE.cmdでv0.3の既存フォルダへ適用する。
元FileをBackupし、ハッシュが異なる私用変更があれば停止する。
10 ToolのPayload/Python/Git runtimeはバイトを変えない。
Source、旧版文書、全既存Testsを保持。外部依存追加なし。
DEVELOPER/build_versioned_zip.py --root ROOT --output OUTPUT.zip
はpackage_files_v031.jsonに従って完全ZIPを再構成し、全File Hashを検証する。
