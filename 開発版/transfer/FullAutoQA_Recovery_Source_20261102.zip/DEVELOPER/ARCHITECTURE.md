> **HISTORICAL CHECKPOINT:** この文書は初期0.1系の設計/受入記録を保存した履歴資料です。現行運用は README.txt、DEVELOPER/GAME_INTEGRATION.md、acceptance_manifest.json、core_manifest.json を優先してください。

# Universal QA implementation checkpoint — not accepted

Version: 0.1.0-candidate. This is implemented source, not a certified finished QA appliance.
Target runtime: Windows x64 interactive desktop, ordinary user, offline. Build host used for the recorded Python tests: Linux. No Windows execution is implied by those tests.

## Boundaries

- `CORE`: Python standard library orchestrator, data contracts, agents, Windows ctypes input/capture/process monitor, video and OBS control, reporting and integrity checks.
- `GAME`: pristine game sources and optional trusted adapter code. Each scenario uses its own working copy. Test save corruption is confined to that copy.
- `PROFILES`: JSON version 1. Profiles and adapters change per game; CORE is not rewritten.
- `PAYLOAD`: the ten exact user-supplied binaries, unmodified, each with size and SHA-256 in `tool_manifest.json`.
- `RUNTIME`: bundled WinPython interpreter; the other ZIP payloads expand inside tool-specific directories. w64devkit invokes its supplied SFX with an explicit local destination. Git Inno Setup is deliberately never installed: its portable extraction is unresolved.
- `RESULTS/<run>`: reports, JSONL logs, screenshots, journal, working copies, full recordings, result ZIP.

`START_QA.cmd` calls process-scoped PowerShell (no permanent execution-policy change). BOOTSTRAP validates CORE and the interpreter's files before Python execution. Python validates exact CORE inventory and the 23-capability contract. Official changes use `CORE/release_manifest.py` as an explicit development release step. Normal START never regenerates hashes.

Integrity detects corruption and modifications against a local manifest. It is not publisher authentication against an attacker who can replace the manifest and bootstrap together. The separately delivered SHA-256 list supports independent archive verification.

## Profile version 1

See the five runnable Godot projects/profiles as concrete examples; the scene implementation accepts a mode argument. Modes have distinct rules: discrete grid/turn, real-time movement, management production/cash, branching dialogue, and seeded procedural dice.

Required fields: `game_id`, `game_version`, `profile_version`, `schema_version`, `prototype_type`, `launch`, `actions`, `goals`, `scenarios`, `tests`, `observations`, `instructions`.

Other fields accepted/used include `source`, `build`, `technical_tests`, `required_assets`, `controls`, `victory`, `defeat`, `save`, `startup_timeout`, `timeout`, `allowed_random_actions`, `forbidden_actions`, `expected_states`, `error_states`, `normal_wait_states`, `state_signature`, `bridge`, `adapter`, `adapter_version`, screenshot/disk limits. Some descriptive fields are preserved without automatic assertions; use explicit `tests` for assertions. Profile values are not independent evidence of gameplay success.

Commands are arrays, executed without a shell. Tokens: `{godot}`, `{python}`, `{java}`, `{node}`, `{git}`, `{c}`, `{ffmpeg}`, `{ahk}`, `{obs}`, `{oculix}`, `{work}`, `{root}`, `{seed}`. Only supplied runtimes are resolved. Build outputs are preserved in the prepared game tree and copied into each scenario's workspace.

Actions map semantic names to typed physical inputs: `key`, `hold`, `combo`, `text`, `move`, `click`, `double_click`, `drag`, `wheel`, `wait`. Coordinates are normalized to the live game client window. Keyboard events use SendInput; keys/buttons are released on normal exception cleanup. If Windows itself kills the process while a key is down, Python finally cannot run; a process death guarantee for key releases has not been established.

Goals use a typed category plus a concrete predicate `field/op/value`. Categories: reach, survive, acquire, defeat, build, produce, transport, select, finish_dialogue, finish_turn, reach_score, reach_resource, trigger_event, save_successfully, load_successfully. These labels alone do not implement genre-specific planning; predicates and profile policies must describe the actual game. Supported predicate operators: eq, ne, gt, ge, lt, le, contains, exists; dotted dictionary paths are supported.

Scenarios name an agent, time/action budgets, an optional goal, a deterministic sequence or conditional policy. Smoke follows its initial sequence; Goal follows policies/sequence then falls back to Explorer; Explorer favors untried state/action pairs; Random uses a recorded Python PRNG seed. This is bounded automation, not guaranteed human-level play.

## Adapter API

A profile can point `adapter` to a Python file under `GAME`. It is trusted executable game-side code, not a security sandbox. It exports:

```python
def create(profile, context):
    return MyAdapter(profile, context)
```

The returned object implements `capabilities()`, `observe()`, `act(action_name)`, and `close()`; `version` is recommended. Context includes desktop, per-run work path, evidence recorder, and local tool resolver. The default adapter supports native keyboard/mouse, native window/capture and an optional atomically-written JSON state file. The Godot fixture state bridge is read-only from the agent's perspective: gameplay actions are real keyboard input, not writes to game state.

Observations can include internal_state, numeric_state, scene, menu, object, grid, position, timer, OCR, audio, window. Unsupported observations are None, never synthesized. The default adapter has no OCR/audio/gamepad backend. An external game-side adapter may implement these, but the present recorder's 30-second readability evaluation still has no validated cognitive proxy.

Navigation utilities include 2D/3D vectors, grid/axial hex neighbors and shortest paths for node/UI/menu graphs. Game-specific reachability, geometry, aiming, collision handling, tooltip recognition and skilled combat are not supplied automatically.

## Process, recording and evidence

Per-scenario game processes are placed in kill-on-close Windows job objects; process trees, CPU time, memory and handles are sampled through native APIs. Working APPDATA/LOCALAPPDATA/TEMP environment paths are isolated. These environment variables do not sandbox software that ignores them or uses Windows Known Folders directly: adapters for those games must relocate user data explicitly before destructive save tests.

Continuous recording uses the bundled FFmpeg gdigrab path, with a required ffprobe video/duration check. OBS is additionally exercised through a local authenticated WebSocket: a portable scene with monitor capture is recorded and probed. OBS is not the continuous recorder in this implementation. No external network service is contacted by CORE. Audio capture is unavailable. Failure clips and a short highlight go into the upload ZIP; full recordings stay in FULL_EVIDENCE, with file size/hash index in the result ZIP. Recording failure is HARNESS_ERROR.

The local OBS RPC implementation follows the official protocol and uses a generated per-start password:
https://github.com/obsproject/obs-websocket/blob/master/docs/generated/protocol.md
https://github.com/obsproject/obs-websocket/blob/master/README.md
These online documents are development references only, not runtime dependencies.

Screenshots are uncompressed 24-bit BMP. Visual regression compares normalized RGB samples with a configurable tolerance, rather than requiring exact full-image pixel identity. It is a simple comparison, not general object recognition or OCR.

Stall detection combines elapsed time, non-progress state, varied input attempts and either unchanged bridge reaction or unchanged screenshot features. Profile wait states suppress candidates during declared normal waits. Recovery refocuses/cancels and switches to Explorer; failure after bounded retries is logged. This heuristic still needs Windows false-positive/false-negative qualification.

Save/load compares explicit state fields after a save/mutate/load sequence. Invalid-save tests restore the copied save in finally. Optional `save.baseline` plus `migration_expected` predicates supports a baseline save load. Multiple slots, autosave semantics and interrupted-write testing are not implemented generically; their cases are NOT_RUN. They require further implementation or game-side tests.

Baseline directory: `BASELINES/<game_id>/<full_case_name>.json`. A baseline records matching `seed` and `scenario`, `expected` predicates, optional `screenshot` relative to that directory, `visual_tolerance`, and optional `performance` metric limits. Measured scenario startup time is available for baseline comparison. Broader performance-baseline automation, frame timing and precise response latency remain incomplete. Input timing in action logs is an observed upper bound including the input duration and observation interval.

Action logs replay semantic actions with the profile's same physical-input mapping through `CORE/replay.py`. Procedural fixtures replay from a pristine process and same seed, compare specified final state fields, and keep both observation sequences. Major defect replay from the exact original save is not yet automatically scheduled for all defect classes; the fault acceptance suite and replay CLI provide only part of that requirement.

Run journal records current profile/scenario/seed and a clean-restart policy. A stale dead-process lock is reclaimed; stateful continuation from an arbitrary interrupted action is not implemented. A new START currently restarts the suite from pristine copies rather than resuming the exact interrupted scenario.

## Result schema 1

Result JSON contains run_id, core_version, result_schema, start/end times, seed, overall, per-test results, coverage, game/profile/adapter versions and a false `human_test_performed`. `completion_certified` remains false in this candidate. Tool manifest and profile snapshots accompany Windows run output.

Each verdict has test_case, status (PASS/FAIL/INCONCLUSIVE/NOT_RUN/HARNESS_ERROR), reason_code, severity, timestamp, event_id, run_id and evidence file references. PASS requires actual referenced files at creation and at final audit. The existence of an evidence file alone cannot establish semantic correctness; assertions and tests supply the check. Overall conservatively includes NOT_RUN/INCONCLUSIVE cases, so optional missing abilities can prevent an overall PASS even if individual required tests pass.

Coverage lists actually executed agents/scenarios/actions/states/goals/test cases. No unobserved coverage percentage is asserted. Evidence manifest records each file's path, size, SHA-256, generation timestamp, run ID and referencing event/test IDs. Reports escape HTML. The result ZIP excludes raw working copies and full video, retaining an index and hashes for full evidence.

## Debug and release

- Run `TESTS/test_core.py` with Python. These are portable contract tests, not Windows acceptance.
- On a Windows desktop, run `TESTS/windows_acceptance.py --zip <candidate.zip> --dest <new directory>` with the bundled interpreter. The script refuses an existing destination, extracts afresh, invokes START, checks each fixture, injects faults and corrupts CORE only in the temporary extraction. It is implemented but has not run in this delivery.
- Review each reason code, screenshots, JSONL timeline and full video. Do not promote by renaming the archive.
- Resolve portable Git extraction, incomplete functionality and all required Windows gates; update CORE version and release manifests; repackage and repeat fresh extraction E2E before any COMPLETE release.

The recorded acceptance report lists what actually ran and the current blockers. It is authoritative over capability declarations and optimistic implementation comments.
