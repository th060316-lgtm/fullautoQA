# 0.2.0 再受入候補

既存0.1.0を保持し、現物のCORE・Fixture・判定・Evidence生成を修正した版です。

実測で確認した変更:

- 仮想画面の実ゲーム別プロセスを標準RFBキー・ポインター入力で操作し、実描画フレームとゲーム自身の状態を観測。
- 5種類の独立した非Godot Fixture、4 Agent、マウスUI、連続移動、ターン・Grid、経営、物語分岐、Seed/Action再現。
- Save/Load、破損Saveの拒否、失敗/Retry。
- 動画とSSを実取得。FFmpeg/ffprobeで動画を検査し、全編をRESULT_FOR_CHATGPT.zipへ同梱。
- Crash、停滞/Softlock、Save失敗、Visual Regression、Action Loop相当の停滞、Missing Assetの故障注入・検出。
- 実時間30秒Soak。実測で作ったBaselineと、出荷用の既知正常BaselineとのVisual/Behavioral/Startup比較。
- REQUIRED / OPTIONAL / UNSUPPORTED_FOR_PROFILE / INFORMATIONALによる判定分離。正常系Overall PASSと、必須Capture欠落時HARNESS_ERRORの両方を確認。
- 元の10Toolペイロードを維持。Gitは公式CIの実バイナリと依存DLLを追加し、常にgit.exe欠損になる構造を修正。PE依存検査は実施、Windows実行は未実施。

Windowsデスクトップ、Godotの実行、10Tool全てのWindows機能試験はこの証拠で代替できません。RFB仮想画面はOSデスクトップではありません。Linux検証ではホストで検出したPythonとFFmpegを使用しており、Linux用自己完結製品を配布したという主張もしません。

この版は全ジャンル完全自動QAの完成認定版ではありません。Gitを含むWindowsの実動資格確認、OculiX視覚操作、旧来の高度なSave/復旧機能等が残ります。再受入判断は外部のRework_Acceptance_v0.2.jsonと実E2E Result ZIPを確認してください。未実施は未実施として記録します。
